 $(document).ready(function(){
            $("#wizard").steps();
			var form = $("#form");
			validator = form.validate({
						rules: {
						first_name: {
							required: {
								depends:function(){
									$(this).val($.trim($(this).val()));
									return true;
								}
							},
							minlength: 3
						},
						last_name:
						{
							required: {
								depends:function(){
									$(this).val($.trim($(this).val()));
									return true;
								}
							},
							minlength: 3
						},
						username: {
							required: {
								depends:function(){
									$(this).val($.trim($(this).val()));
									return true;
								}
							},
							minlength: 3,
							remote: function() {
							return {
							url: '/user/user_auth/login/validate_uname/' + $('#username').val(),
							data: '',
							type: "post",
							dataFilter: function (data) {
								if(data!=""){
								return 'false';// If email not exist	
								}else{
								return 'true';// If email exist ( Display message on return true )	
									}
								}
							}
						}
						},
						password:
						{
							required: true,
							pwcheck :true,
							minlength: 8
						},
						cpassword:
						{
							required: true,
							minlength: 8,
						    equalTo: "#cust-password"
						},
						m_a_street_number:
						{
							required: {
								depends:function(){
									$(this).val($.trim($(this).val()));
									return true;
								}
							},
							maxlength:10
						},
						m_a_street_address:
						{
							required: {
								depends:function(){
									$(this).val($.trim($(this).val()));
									return true;
								}
							}
						},
						email:
						{
							required: true,
							email: true,
							remote: function() {
						return {
							url: '/user/user_auth/login/ValidateEmail/' + $('#email').val(),
							data: '',
							type: "post",
							dataFilter: function (data) {
								if(data!=""){
								return 'false';// If email not exist	
								}else{
								return 'true';// If email exist ( Display message on return true )	
								}
							}
						}
					}
						},
						m_a_postal_code:{
							required: {
							depends:function(){
								 var dest = $(this);
								 dest.val(dest.val().split(" ").join("")); 
									return true;
								}
							},
							regex: /^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$/
						},
						c_phn:{
							required: true,
							regex: /^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$/,
						},
						b_a_street_number:
						{
							required: {
								depends:function(){
									$(this).val($.trim($(this).val()));
									return true;
								}
							},
							maxlength: 10
						},
						b_a_street_address:
						{
							required: {
								depends:function(){
									$(this).val($.trim($(this).val()));
									return true;
								}
							}
						},
						b_a_postal_code:
						{
							required: true,
							regex: /^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$/
						}
					},
					messages:
					 {
						 first_name:
						 {
							required: "Please enter Firstname.",
							minlength: "Please enter atleast 3 characters."
						 },
						 last_name: 
						 {
							required: "Please enter Lastname.",
							minlength: "Please enter atleast 3 characters."
						 },
						 username: {
							required: "Please enter Username.",
							remote: jQuery.validator.format("{0} not available try another.")
						},
						password:
						{
							required: "Please enter Password.",
							pwcheck :"Password format should be like(A-Za-z0-9-#$%!^&*@._*)",
							minlength: 8					  
						},
					    cpassword: 
						{
							required: "Please enter Confirm Password.",
							equalTo: "confirm password not matching with password"
						},
						m_a_street_number: 
						{
							required: "Please enter Street Number.",
							max: "maximum 10 characters are allowed"
						},
						m_a_street_address: 
						{
							regex: "Please enter valid Street Address."
						},
						email: {
							required: "Please enter your email.",
							email: "Please enter valid email.",	
							remote: jQuery.validator.format("{0} not available try another.")
						 },
						m_a_postal_code:{
							required: "Please enter Postal Code.",
							regex: "Please enter valid Postal Code."
						},
						c_phn:{
							required: "Please enter Cell Phone.",
							regex:  "Please enter valid phone number."
						},
						b_a_street_number:
						{
							required: "Please enter Street Number.",
							max: "maximum 10 characters are allowed"
						},
						b_a_street_address:
						{
							required: "Please enter Street Address."
						},
						b_a_postal_code:
						{
							required: "Please enter Postal Code.",
							regex: "Please enter valid Postal Code."
						}
					 }
					  
				});
			
            $("#form").steps({
                bodyTag: "fieldset",
                onStepChanging: function (event, currentIndex, newIndex)
                {
                    // Always allow going backward even if the current step contains invalid fields!
                    if (currentIndex > newIndex)
                    {
                        return true;
                    }

                    var form = $(this);

                    // Clean up if user went backward before
                    if (currentIndex < newIndex)
                    {
                        // To remove error styles
                        $(".body:eq(" + newIndex + ") label.error", form).remove();
                        $(".body:eq(" + newIndex + ") .error", form).removeClass("error");
                    }

                    // Disable validation on fields that are disabled or hidden.
                    form.validate().settings.ignore = ":disabled,:hidden";
                    // Start validation; Prevent going forward if false
                    return form.valid();
                },
                onStepChanged: function (event, currentIndex, priorIndex)
                {
                    // Suppress (skip) "Warning" step if the user is old enough.
                    if (currentIndex === 2 && Number($("#age").val()) >= 18)
                    {
                        $(this).steps("next");
                    }

                    // Suppress (skip) "Warning" step if the user is old enough and wants to the previous step.
                    if (currentIndex === 2 && priorIndex === 3)
                    {
                        $(this).steps("previous");
                    }
                },
                onFinishing: function (event, currentIndex)
                {
                    var form = $(this);

                    // Disable validation on fields that are disabled.
                    // At this point it's recommended to do an overall check (mean ignoring only disabled fields)
                    form.validate().settings.ignore = ":disabled";

                    // Start validation; Prevent form submission if false
                    return form.valid();
                },
                onFinished: function (event, currentIndex)
                {
                    var form = $(this);
					$.ajax({
							type: "POST",
							url: "/user/profile/profile/save_user/",
							data: $(form).serialize()
						})
						.done(function (response) {
						console.log(response);
						
							if(response == 'addsuccess'){
							var msg="Customer added successfully";
							}else{
							var msg="Customer updated successfully";
							}							
					 setTimeout(function() {
						swal({
							title: "Success!!",
							text: msg,
							type: "success"
						}, function() {
							window.location = "/user/user_auth/login/dashboard";
						});
					}, 1000);	
						} );
					//save_user

                    // Submit form input
                    //form.submit();
                }
            }).validate({
                        errorPlacement: function (error, element)
                        {
                            element.after(error);
                        },
                        rules: {
                            confirm: {
                                equalTo: "#cust-password"
                            }
                        }
                    });
					
					$.validator.addMethod("valueNotEquals", function(value, element, arg){
					  return arg !== value;
					 }, "Value must not equal arg.");
					
		   $("#detail_same").click(function(){
										
						if($(this).is(':checked')){
							 $("[name='b_a_street_number']").val($("[name='m_a_street_number']").val());
						  $("[name='b_a_street_address']").val($("[name='m_a_street_address']").val());
						  $("[name='b_a_postal_code']").val($("[name='m_a_postal_code']").val());
							
							<!--get province List-->
							
							 $.ajax({
									url: "/admin/customer/customer/get_province_list/"+$("#m_a_country").val(),
									global:"false",
									async:true,
									beforeSend: function(){ 
								   $("#b_a_state").empty(); 
								   }
								 }).done(function( data ) {
								   $('#b_a_state').append(data);
								   $("#b_a_state").trigger("chosen:updated");
								   $("#b_a_state").trigger("liszt:updated");
								});
							<!--get province List-->
							
							<!--get city List-->
							
							  $.ajax({
								url: "/admin/customer/customer/get_cities_list/"+$("#m_a_state").val(),
								global:"false",
								async:true,
								beforeSend: function(){ 
								   $("#b_a_city").empty(); 
								   }
								 }).
								 done(function(data) 
								 {
								   $('#b_a_city').append(data);
								   $("#b_a_city").trigger("chosen:updated");
								   $("#b_a_city").trigger("liszt:updated");
									var city1=$("[name='m_a_city']").val();
									var country1=$("[name='m_a_country']").val();
									var province1=$("[name='m_a_state']").val();
									
									  $("[name='b_a_country']").val(country1);
									  $("[name='b_a_country']").trigger("chosen:updated");
																 
									  $("[name='b_a_city']").val(city1);
									  $("[name='b_a_city']").trigger("chosen:updated");
									 
								   $("[name='b_a_state']").val(province1);
								   $("[name='b_a_state']").trigger("chosen:updated");
									 });
						}else{
								$("[name='b_a_city']").empty(); //remove all child nodes
								var newOption = $('<option value="">Select City</option>');
								$("[name='b_a_city']").append(newOption);
								$("[name='b_a_city']").trigger("chosen:updated");
								
								$("[name='b_a_state']").empty(); //remove all child nodes
								var newOption = $('<option value="">Select State</option>');
								$("[name='b_a_state']").append(newOption);
								$("[name='b_a_state']").trigger("chosen:updated");
								
								 $("[name='b_a_street_number']").val('');
							     $("[name='b_a_street_address']").val('');
							     $("[name='b_a_postal_code']").val('');
						}
					});
					
			$('.chosen-select').chosen({width: "100%"});
			
			 $('#data_1 .input-group.date').datepicker({
                startView: 2,
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true
            });
			
			$.validator.addMethod(
				  "regex",
				   function(value, element, regexp) {
					   if (regexp.constructor != RegExp)
						  regexp = new RegExp(regexp);
					   else if (regexp.global)
						  regexp.lastIndex = 0;
						  return this.optional(element) || regexp.test(value);
				   },"Please enter valid value"
				);
				
				$("#m_a_country").change(function(){       
						 $.ajax({
									url: "/admin/customer/customer/get_province_list/"+$("#m_a_country").val(),
									global:"false",
									async:true,
									beforeSend: function(){ 
								   $("#m_a_state").empty(); 
								   }
								 }).done(function( data ) {
								   $('#m_a_state').append(data);
								   $("#m_a_state").trigger("chosen:updated");
								   $("#m_a_state").trigger("liszt:updated");
								   if($("#m_a_country").val() != ''){
								   var country_code=$("#m_a_country").val().toLowerCase();
								   //console.log(data);
								   }
								  });
								  $.post("/admin/customer/customer/get_country_code/"+$('#m_a_country').val(), function(data2, status){
									$("#h_c_code").val(data2);
									$("#cl_c_code").val(data2);
								});	
								});
								
								
				$("#m_a_state").change(function(){       
					 $.ajax({
								url: "/admin/customer/customer/get_cities_list/"+$("#m_a_state").val(),
								global:"false",
								async:true,
								beforeSend: function(){ 
								   $("#m_a_city").empty(); 
								   }
								 }).
								 done(function(data) 
								 {
								   $('#m_a_city').append(data);
								   $("#m_a_city").trigger("chosen:updated");
								   $("#m_a_city").trigger("liszt:updated");
								 });
								});
								
				$("#b_a_country").change(function(){       
						 $.ajax({
									url: "/admin/customer/customer/get_province_list/"+$("#b_a_country").val(),
									global:"false",
									async:true,
									beforeSend: function(){ 
								   $("#b_a_state").empty(); 
								   }
								 }).done(function( data ) {
								   $('#b_a_state').append(data);
								   $("#b_a_state").trigger("chosen:updated");
								   $("#b_a_state").trigger("liszt:updated");
								 });
								 	
								});
								
								
				$("#b_a_state").change(function(){       
					 $.ajax({
								url: "/admin/customer/customer/get_cities_list/"+$("#b_a_state").val(),
								global:"false",
								async:true,
								beforeSend: function(){ 
								   $("#b_a_city").empty(); 
								   }
								 }).
								 done(function(data) 
								 {
								   $('#b_a_city').append(data);
								   $("#b_a_city").trigger("chosen:updated");
								   $("#b_a_city").trigger("liszt:updated");
								 });
								});	

					$.validator.addMethod("pwcheck", function(value) {
							   return /^[A-Za-z0-9\d=!\-@._*]*$/.test(value) // consists of only these
								   && /[A-Z]/.test(value) // has a uppercase letter
								   && /[a-z]/.test(value) // has a lowercase letter
								   && /\d/.test(value) // has a digit
								   && /[!@#$%^&*]/.test(value)
							});	
							
						var country_phn_cd=$("#b_a_country").val().toLowerCase();
											
						});
						
						$(document).ready(function(){
            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green',
                radioClass: 'iradio_square-green',
            });
			
			$("#forgot_password").validate({
				rules: {
				email:
                {
                    required: true,
                    email: true,
					remote: function() {
                return {
                    url: '/user/user_auth/login/ValidateEmail/' + $('#email').val(),
                    data: '',
					type: "post",
					dataFilter: function (data) {
						
						if(data!=""){
						return 'true';// If email exist	
						}else{
						return 'false';// If email not exist 	
						}
                    }
                }
            }
				}
			},
			messages:
             {
				 email: {
                    required: "Please enter your email.",
					email: "Please enter valid email.",	
					remote: jQuery.validator.format("{0} Not exists in our database.")
                 }
             },
			  submitHandler: function(form) {
				$.ajax({
				url: '/user/user_auth/register/forgot_password_sendMail',
				type: "post",
				data: $(form).serialize(),
				success: function(response) {
					$("#forgot_password")[0].reset();
					$(".alert-success").show();
				  $(".alert-success").text("Password reset link has been sent to your email id.Please check").fadeIn("slow");
				}            
				});
			  }
		});
		
        });