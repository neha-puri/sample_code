<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
	parent::__construct();
	// Load url helper
	$this->load->helper('asset_helper','url');
	// Load session library
	$this->load->library('session');

	// Load database
	$this->load->model('user/profile/profile_model');
	//$this->load->helper('url');
	}
	public function index()
	{
		$data = array();
			$this->load->helper('form');
						
			if(isset($_SESSION['logged_in']) && $_SESSION['logged_in']!="" ){
			$id=$_SESSION['logged_in']['user_id'];
			$data['country'] = $this->profile_model->get_country_list();
			$data['country1'] = $this->profile_model->get_country_list();
			$data["data"] = $this->profile_model->get_user_detail($id);
			$data['province'] = $this->profile_model->get_province_list($data["data"]->m_a_country);
			$data['province1'] = $this->profile_model->get_province_list($data["data"]->b_a_country);
			$data['city'] = $this->profile_model->get_cities_list($data["data"]->m_a_province);
			$data['city1'] = $this->profile_model->get_cities_list($data["data"]->b_a_province);
			
			if((isset($_SESSION['logged_in']['username']) && $_SESSION['logged_in']['username']!="") && (isset($_SESSION['logged_in']['password']) && $_SESSION['logged_in']['password']!="") && (isset($_SESSION['logged_in']['role']) && $_SESSION['logged_in']['role']="user")) {
				$this->load->view('includes/user/header');
				$this->load->view('includes/user/sidebar');
				$this->load->view('user/profile/edit_profile',$data);
				$this->load->view('includes/user/footer');
			}
			}
			else{	
			redirect('/login', 'refresh');
			}
	}
	
	public function save_user()
	{
		   $data = $this->profile_model->save_user();
	}
	
	public function get_cities_list($id)
	{
		   $data = $this->profile_model->get_cities_list($id);
		   echo "<option value=''>Select</option>";
		   foreach($data as $k=>$v){
			   echo "<option value='".$v->city."'>".$v->city."</option>";
		   }
	}
	public function get_province_list($id)
	{
		   $data = $this->profile_model->get_province_list($id);
		   echo "<option value=''>Select</option>";
		   foreach($data as $k=>$v){
			   echo "<option value='".$v->state."'>".$v->state."</option>";
		   }
	}
}
