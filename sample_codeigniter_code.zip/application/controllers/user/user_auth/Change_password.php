<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Change_Password extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	function __construct() {
	parent::__construct();
	// Load url helper
	$this->load->helper('asset_helper');
	// Load database
	$this->load->model('user/user_auth/register_model');
	$this->load->helper('url');
	}
	public function index()	{		//$createdby  =   $this->session->userdata();
		$this->load->view('includes/user/header');
		$this->load->view('user/user_auth/change_password');
		$this->load->view('includes/footer');
	}	
	public function password_change()	
	{
		$postData = $this->input->post();
		  
           $data = $this->register_model->change_password($postData['password'],$postData['oldpassword']); die();
		   if($data==1){
			   return $data;
		   }
	}
	
	}
