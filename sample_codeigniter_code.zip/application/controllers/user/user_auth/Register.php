<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	function __construct() {
	parent::__construct();
	// Load url helper
	$this->load->helper('asset_helper');
	// Load database
	$this->load->model('user/user_auth/register_model');
	$this->load->helper('url');
	$this->load->library('session');
	}
	public function index()
	{
		$data = $this->register_model->get_terms_conditions();
		if(isset($data[0]->description) && $data[0]->description!=""){
		$data['description'] = $data[0]->description;
		}
		$this->load->view('includes/user/header');
		$this->load->view('user/user_auth/register',$data);
		$this->load->view('includes/user/footer');
	}
	public function register()
	{
	if($this->input->post('submit') != NULL ){
     // POST data
     $postData = $this->input->post();
	}
           $data = $this->register_model->adduser($postData);
		 
		 if($data!=""){
			 $this->verify_email_sendMail($data);
		 }
	}
	public function verify_email_sendMail($data)
		{
			  $data= (explode(",",$data)); 
			  $hash=$data[0];
			  $email=$data[1];
			  $pwd=$data[2];
			  $uname=$data[3];
			  $data = $this->register_model->get_user_detail($email);
              $message = "Thanks for signing up!<br>
						   Your account has been created, you can login with the following credentials after you have activated your account by pressing the link below.<br>
						   ------------------------<br>
							Username: ".$uname.
							"<br>Password: ".$pwd."
							<br>------------------------<br>Please click this link to activate your account:<br><a href='https://www.staging.globalassetcare.com/user/user_auth/register/verify_account/".$data[0]->user_id."/".$hash."'>https://www.staging.globalassetcare.com/user/user_auth/register/verify_account/".$data[0]->user_id."/".$hash."</a>";
							
						  $config = Array(
						  'protocol' => 'smtp',
						  'smtp_host' => 'ssl://mail.globalassetcare.com',
						  'smtp_port' => 465,
						  'smtp_user' => 'support@globalassetcare.com', // change it to yours
						  'smtp_pass' => 'P$%^ssw0rd123', // change it to yours
						  'mailtype' => 'html',
						  'charset' => 'iso-8859-1',
						  'wordwrap' => TRUE
						); 
						
			  $this->load->library('email', $config);		
			  $this->email->set_newline("\r\n");
			  $this->email->from("support@globalassetcare.com"); // change it to yours
			  //$this->email->from("nehapuri48@gmail.com"); // change it to yours
			  $this->email->to($email);// change it to yours
			  $this->email->subject('Thank you for creating an account');
			  $this->email->message($message);
			  if($this->email->send())
			 {
			  echo 'Email sent.'; die();
			 }
			 else
			{
			 show_error($this->email->print_debugger()); die();
			}
		}
		public function forgot_password_sendMail()
		{
			$postData = $this->input->post();
			$tmp_password = rand(100000,150000);
			$this->register_model->update_user_pwd($tmp_password,$postData['email']);
			$data = $this->register_model->get_user_detail($postData['email']);
			  $hash=$data[0]->hash;
			  $email=$data[0]->email;
			  $user_id=$data[0]->user_id;
			  $message = "To change your password click on below link.<br>
						  
						  <a href='https://www.staging.globalassetcare.com/user/user_auth/register/change_password_verify/".$user_id."/".$hash."'>https://www.staging.globalassetcare.com/user/user_auth/register/change_password_verify/".$user_id."/".$hash."</a><br>Password=".$tmp_password;
						  $config = Array(
						  'protocol' => 'smtp',
						  'smtp_host' => 'ssl://mail.globalassetcare.com',
						  'smtp_port' => 465,
						  'smtp_user' => 'support@globalassetcare.com', // change it to yours
						  'smtp_pass' => 'P$%^ssw0rd123', // change it to yours
						  'mailtype' => 'html',
						  'charset' => 'iso-8859-1',
						  'wordwrap' => TRUE
						);
			  $this->load->library('email', $config);		
			  $this->email->set_newline("\r\n");
			  $this->email->from("support@globalassetcare.com"); // change it to yours
			  $this->email->to($email);// change it to yours
			  $this->email->subject('Password Change Request');
			  $this->email->message($message);
			  
			  echo $message;
			  
			  if($this->email->send())
			 {
			  echo 'Email sent.'; die();
			 }
			 else
			{
			 show_error($this->email->print_debugger()); die();
			} 
		}
	public function verify_account()
	{
		 $user_id = $this->uri->segment(5, 0);
		 $hash = $this->uri->segment(6, 0); 
		 
		 $data = $this->register_model->user_verified($user_id,$hash); 
		 
		 if($data==1){
				if ($user_id != "" && $hash != "" ) {
				$session_data = array(
				'user_id' => $user_id,
				'hash' => $hash,
				'email_verify' => '1',
				);
				// Add user data in session
				$this->session->set_userdata('logged_in', $session_data);
				$result="success";
				}
			 redirect('/change_password');
		 }
		 if($data==0){
			 $session_data = array(
				'link_expired' => "1"
				);
				// Add user data in session
				$this->session->set_userdata('logged_in', $session_data);
			 redirect('user/user_auth/login');
		 }
		 //echo $result;
	}
	public function change_password_verify()
	{
		 $userid = $this->uri->segment(5, 0);
		 $hash = $this->uri->segment(6, 0); 
		 $result="";
		
				if ($userid != "" && $hash != "" ) {
				$session_data = array(
				'user_id' => $userid,
				'hash' => $hash,
				'password_change' => '1',
				);
				// Add user data in session
				$this->session->set_userdata('logged_in', $session_data);
				$result="success";
				}
			 redirect('/change_password');
		 
		 //echo $result;
	}
	}
