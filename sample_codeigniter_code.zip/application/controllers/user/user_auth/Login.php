<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	function __construct() {
	parent::__construct();
	// Load url helper
	$this->load->helper('asset_helper','url');
	// Load session library
	$this->load->library('session');

	// Load database
	$this->load->model('user/user_auth/login_model');
	//$this->load->helper('url');
	$this->load->helper('cookie');
	}
	public function index()
	{
		$this->load->view('includes/user/header');
		$this->load->view('user/user_auth/login');
		$this->load->view('includes/user/footer');
	}
	
	public function dashboard(){
	    $createdby  =   $this->session->userdata();
		
		
		
		if((isset($createdby['logged_in']['username']) && $createdby['logged_in']['username']!="") && (isset($createdby['logged_in']['password']) && $createdby['logged_in']['password']!="")){
			
			 $data = $this->login_model->get_login_user_id($createdby['logged_in']['username'],$createdby['logged_in']['password']);
			 
			 if(isset($data->firstname) && $data->firstname!=""){
				$this->load->view('includes/user/header');
				$this->load->view('includes/user/sidebar');
				$this->load->view('user/user_auth/dashboard'); 
				$this->load->view('includes/user/footer');
			 }else{
				 redirect('user/profile/profile', 'refresh');
			 }
		}else{	
		redirect('/login', 'refresh');
		}
	}
	public function validate_uname()
	{
		 $uname = $this->uri->segment(5, 0);
		 
		 echo $data = $this->login_model->validate_username($uname);
	}
	public function validate_password(){
		//$hashid = $this->uri->segment(5, 0);
		$postData = $this->input->post();

		if(isset($_SESSION['logged_in']['user_id'])&& $_SESSION['logged_in']['user_id']!=""){
			$userid=$_SESSION['logged_in']['user_id'];
		}else{
			$userid=$postData['userid'];
		}
		$pwd = $postData['password'];
		 
		//echo $data = $this->login_model->validate_password($pwd,$hashid);
		echo $data = $this->login_model->validate_password($pwd,$userid);
	}
	public function validateEmail($email)
	{
         echo $data = $this->login_model->validate_email($email);
	}
	public function checklogin()
	{
		   $postData = $this->input->post();

		   $uname = $postData['uname'];
		   $pwd = $postData['password'];
		   $remember_me = $postData['remember_me']; 

		   if(isset($remember_me) && ($remember_me=="true" || $remember_me=="on")){
			   setcookie('username',$uname,time()+(3600*24*7), '/');
			   setcookie('password',$pwd,time()+(3600*24*7), '/');
			   setcookie('rememberme',1,time()+(3600*24*7), '/'); 
		   }else{
			   delete_cookie('username'); 
			   delete_cookie('password');
			   delete_cookie('rememberme'); 
		   }		
         echo $data = $this->login_model->checklogin($uname,$pwd);
	}
	public function addlogincount($uname,$pwd)
	{
		 
         echo $data = $this->login_model->addlogincount($uname,$pwd);
	}
	// Check for user login process
	public function user_login_process() {
		$postData = $this->input->post();
		$uname = $postData['uname'];
	    $pwd = $postData['password'];
		
	 $data = $this->login_model->get_login_user_id($uname,$pwd);
	
	if ($uname != "" && $pwd != "" ) {
	$session_data = array(
	'username' => $uname,
	'password' => $pwd,
	'user_id'=> $data->user_id,
	'account_number'=> $data->account_number,
	'role'=>'user'
	);
	// Add user data in session
	$this->session->set_userdata('logged_in', $session_data);
	echo $data="success";
 	}
	}

	 public function register()
	{
	$this->load->model('user/user_auth/user');
		 
	if($this->input->post('submit') != NULL ){
 
     // POST data
     $postData = $this->input->post();
	}
         echo $data = $this->user->adduser($postData);
	} 
	function logout()
	{
		$user_data = $this->session->all_userdata();
			foreach ($user_data as $key => $value) {
			$this->session->unset_userdata($key);
			}
		$this->session->sess_destroy();
		redirect('/login');
	}
	function forgot_password(){
		$this->load->view('includes/user/header');
		$this->load->view('user/user_auth/forgot_password');
		$this->load->view('includes/user/header');
	}
}
