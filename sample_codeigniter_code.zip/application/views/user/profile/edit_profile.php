	<?php 
		$username="";
		$email="";
		$password="";
		$DOB="02/02/1987";
		$firstname="";
		$lastname="";
		$m_a_street_number="";
		$m_a_street_address="";
		$m_a_city="";
		$m_a_province="";
		$m_a_country="";
		$m_a_postal_code="";
		$b_a_city="";
		$b_a_province="";
		$b_a_country="";
		$b_a_postal_code="";
		$b_a_street_number="";
		$b_a_street_address="";
		$home_phn="";
		$cell_phn="";
		$note="";
		$user_id=0;
		$h_c_code="";
		$cl_c_code="";
		if (!empty($data)) 
		{
			$user_id=$data->user_id;	
			$username=$data->username;
			$email=$data->email;
			$password=$data->password;
			if(isset($data->DOB) && $data->DOB!=""){
			$DOB=date('m/d/Y', $data->DOB);
			}
			$firstname=$data->firstname;
			$lastname=$data->lastname;
			$m_a_street_number=$data->m_a_street_number;
			$m_a_street_address=$data->m_a_street_address;
			$m_a_city=$data->m_a_city;
			$m_a_province=$data->m_a_province;
			$m_a_country=$data->m_a_country;
			$m_a_postal_code=$data->m_a_postal_code;
			$b_a_city=$data->b_a_city;
			$b_a_province=$data->b_a_province;
			$b_a_country=$data->b_a_country;
			$b_a_postal_code=$data->b_a_postal_code;
			$b_a_street_number=$data->b_a_street_number;
			$b_a_street_address=$data->b_a_street_address;
			$home_phn=$data->home_phn;
			$cell_phn=$data->cell_phn;
			$h_c_code=$data->h_c_code;
			$cl_c_code=$data->cl_c_code;
			$note=$data->note;		
		}?>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
				<h2><?php if(isset($user_id)&&($user_id!="")){echo "Edit Customer";}else{echo "Add Customer";} ?></h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">Customer</a>
                        </li>
                        <li class="active">
                            <strong><?php if(isset($user_id)&&($user_id!="")){echo "Edit Customer";}else{echo "Add Customer";} ?></strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>
        <div class="wrapper wrapper-content animated fadeInRight">
			<div class="row">
                <div class="col-lg-12">
                    <div class="ibox">
                        <div class="ibox-content">
                            <!--<form id="form" action="#" class="wizard-big">-->
							<form class="m-t wizard-big" role="form" action="#" id="form">
                                <h1>Account</h1>
                                <fieldset>
                                    <div class="row">
                                        <div class="col-lg-8">
                                            <div class="form-group">
											    <span>Last name *</span>
                                                <input id="last_name" name="last_name" type="text" class="form-control" value="<?php echo $lastname;?>"  Placeholder="Last Name">
                                            </div>
                                            <div class="form-group">
												<span>First name *</span>
												<input id="first_name" name="first_name" type="text" class="form-control" value="<?php echo $firstname;?>"  Placeholder="First Name">
											</div>
                                            <div class="form-group" id="data_1">
												<label class="font-normal">Date Of Birth</label>
												<div class="input-group date">
													<span class="input-group-addon"><i class="fa fa-calendar"></i></span><input style="margin-top:0px" type="text" id="dob" class="form-control" name="dob" value="<?php echo $DOB;?>">
												</div>
											</div>
										 	<div class="form-group">
											    <span>Username *</span>
												<?php  //if($username!=""){ ?>
                                                <input id="username" name="username" type="text" class="form-control" value="<?php echo $username;?>"  Placeholder="Username" <?php if($username!=""){echo "disabled";} ?>>
												<?php //} ?>
                                            </div>
											<div class="form-group">
											    <span>Password *</span>
                                                <input id="cust-password" name="password" type="text" class="form-control" value="<?php echo $password;?>"  Placeholder="Password" <?php if($password!=""){echo "disabled";} ?>>
                                            </div>
											<?php if($password==""){ ?>
											<div class="form-group">
											    <span>Confirm Password *</span>
                                                <input id="cpassword" name="cpassword" type="text" class="form-control" Placeholder="Confirm Password">
                                            </div> 
											<?php } ?>
											</div>
                                        <div class="col-lg-4">
                                            <div class="text-center">
                                                <div style="margin-top: 20px">
                                                    <i class="fa fa-sign-in" style="font-size: 180px;color: #e5e5e5 "></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </fieldset>
                                <h1>Mailing Address</h1>
                                <fieldset>
								
                                     <div class="row">
									 
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Street (House) Number *</label>
                                                <input id="m_a_street_number" name="m_a_street_number" type="text" value="<?php echo $m_a_street_number;?>"  class="form-control">
                                            </div>
                                            <div class="form-group">
                                                <label>Street Address *</label>
                                                <input id="m_a_street_address" name="m_a_street_address" type="text" value="<?php echo $m_a_street_address;?>" class="form-control">
                                            </div>
										<div class="form-group">
												<label>Country *</label>
												<div>
												<select name="m_a_country" id="m_a_country" data-placeholder="Choose a Country..." class="chosen-select"  tabindex="2">
												<option value disabled selected>Select Country</option>
												<?php
												foreach($country as $country) {
											    if($m_a_country == $country->country_code) {$s = " selected=selected";}else{ $s = "";}
												echo "<option value='".$country->country_code."' ".$s.">". $country->country."</option>";
												}
												?>
												</select>
												</div>
											</div>
											<div class="form-group">
												<label>Province *</label>
												<div>
												<select name="m_a_state" id="m_a_state" data-placeholder="Choose a Province..." class="chosen-select"  tabindex="2">
												<option value=" ">Select</option>
												<?php
												foreach($province as $province) {
											    if($m_a_province == $province->state) {$s = " selected=selected";}else{ $s = "";}
												echo "<option value='".$province->state."' ".$s.">". $province->state."</option>";
												}
												?>
												</select>
												</div>
											</div>
											<div class="form-group">
											    <label>Email *</label>
                                                <input id="email" name="email" type="text" class="form-control" value="<?php echo $email;?>"  Placeholder="Email" <?php if($email!=""){echo "disabled";} ?>>
                                            </div>
                                       </div>
                                        <div class="col-lg-6">
                                          <div class="form-group">
												<label>City *</label>
												<div>
												<select  name="m_a_city" id="m_a_city" data-placeholder="Choose a City..." class="chosen-select"  tabindex="2">
												<option value=" ">Select</option>
												<?php
												
												foreach($city as $city) {
											    if($m_a_city == $city->city) {$s = " selected=selected";}else{ $s = "";}
												echo "<option value='".$city->city."' ".$s.">". $city->city."</option>";
												}
												
												?>
												</select>
												</div>
											</div>
											<div class="form-group">
                                                <label>Postal Code *</label>
                                                <input id="m_a_postal_code" name="m_a_postal_code" type="text" value="<?php echo $m_a_postal_code;?>" class="form-control">
                                            </div>
											<div class="form-group">
                                                 <label>Home Phone</label>
												<div class="row">
												<div class="col-md-2 col-sm-4 col-xs-5">
												<input id="h_c_code" name="h_c_code"  type="text" value="<?php echo $h_c_code;?>" class="form-control" placeholder="+1">
												</div>
												
												<div class="col-md-10 col-sm-8 col-xs-7">
												<input id="h_phn" name="h_phn" type="text" value="<?php echo $home_phn;?>" class="form-control" data-mask="(999) 999-9999" placeholder="">
												<span class="help-block">(999) 999-9999</span>
												</div>
												</div> 
												</div>
										
											<div class="form-group cl_phn">
                                                <label>Cell Phone *</label>
												<div class="row">
												<div class="col-md-2 col-sm-4 col-xs-5">
												<input id="cl_c_code" name="cl_c_code" type="text" value="<?php echo $cl_c_code;?>" class="form-control" placeholder="+1">
												</div>
												<div class="col-md-10 col-sm-8 col-xs-7">
												<input id="c_phn" value="<?php echo $cell_phn;?>" name="c_phn" type="text" class="form-control" data-mask="(999) 999-9999" placeholder="">
												<span class="help-block">(999) 999-9999</span>
												</div>
												</div> 
                                            </div>
											
											<div class="form-group hm_phn">
                                                <label>Note </label>
                                                <textarea class="form-control" name="note" id="note"><?php echo $note;?> </textarea>
                                            </div>
                                        </div>
                                    </div>
                                </fieldset>

                                <h1>Billing Address</h1>
                                <fieldset>
								<div class="row">
								 <div class="col-lg-6">
											<div class="form-group">
													<input name="detail_same" id="detail_same"  type="checkbox">
													<label style="margin-left:26px;">Billing Address Same as Mailing Address</label>
											</div>
								</div>
								</div>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Street Number *</label>
                                                <input id="b_a_street_number" name="b_a_street_number"  value="<?php echo $b_a_street_number;?>"  type="text" class="form-control">
                                            </div>
                                            <div class="form-group">
                                                <label>Street Address *</label>
                                                <input id="b_a_street_address" name="b_a_street_address" value="<?php echo $b_a_street_address;?>"  type="text" class="form-control">
                                            </div>
											<div class="form-group">
                                                <label>Postal Code *</label>
                                                <input id="b_a_postal_code" name="b_a_postal_code" value="<?php echo $b_a_postal_code;?>"  type="text" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
											
											<div class="form-group">
												<label>Country *</label>
												<div>
												<select name="b_a_country" id="b_a_country" data-placeholder="Choose a Country..." class="chosen-select"  tabindex="2">
												<option value disabled selected>Select Country</option>
												<?php
												foreach($country1 as $country1) {
											    if($b_a_country == $country1->country_code) {$s = " selected=selected";}else{ $s = "";}
												echo "<option value='".$country1->country_code."' ".$s.">". $country1->country."</option>";
												}
												
												?>
												</select>
												</div>
											</div>
											
											<div class="form-group">
												<label>Province *</label>
												<div>
												<select name="b_a_state" id="b_a_state" data-placeholder="Choose a Province..." class="chosen-select"  tabindex="2">
												<option value=" ">Select</option>
												<?php
												foreach($province1 as $province1) {
											    if($b_a_province == $province1->state) {$s = " selected=selected";}else{ $s = "";}
												echo "<option value='".$province1->state."' ".$s.">". $province1->state."</option>";
												}
												?>
												</select>
												</div>
											</div>
                                          <div class="form-group">
												<label>City *</label>
												<div>
												<select  name="b_a_city" id="b_a_city" data-placeholder="Choose a City..." class="chosen-select"  tabindex="2">
												<option value=" ">Select</option>
												<?php
												foreach($city1 as $city1) {
											    if($b_a_city == $city1->city) {$s = " selected=selected";}else{ $s = "";}
												echo "<option value='".$city1->city."' ".$s.">". $city1->city."</option>";
												}
												?>
												</select>
												</div>
											</div>	
                                        </div>
                                    </div>
                                </fieldset>
                             <input type="hidden" name="user_id" id="user_id" value="<?php echo $user_id; ?>">
                            </form>
                        </div>
                    </div>
                    </div>

                </div>
        </div>
        <div class="footer">
            <div class="pull-right">
                10GB of <strong>250GB</strong> Free.
            </div>
            <div>
                <strong>Copyright</strong> Example Company &copy; 2014-2017
            </div>
        </div>

        </div>
      </div>

    <!-- Mainly scripts -->
    <script src="<?php echo js_url("jquery-3.1.1.min.js")?>"></script>
    <script src="<?php echo js_url("bootstrap.min.js")?>"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo js_url("inspinia.js")?>"></script>
    <script src="<?php echo js_url("plugins/pace/pace.min.js")?>"></script>
	<script src="<?php echo js_url("plugins/slimscroll/jquery.slimscroll.min.js")?>"></script>
    <!-- Chosen -->
    <script src="<?php echo js_url("plugins/chosen/chosen.jquery.js")?>"></script>
	<script src="<?php echo js_url("plugins/datapicker/bootstrap-datepicker.js")?>"></script>
	  <!-- MENU -->
    <script src="<?php echo js_url("plugins/metisMenu/jquery.metisMenu.js")?>"></script>

    <!-- Input Mask-->
    <script src="<?php echo js_url("plugins/jasny/jasny-bootstrap.min.js")?>"></script>
	
   <script src="<?php echo js_url("plugins/steps/jquery.steps.min.js")?>"></script>
	<!-- Jquery Validate -->
    <script src="<?php echo js_url("plugins/validate/jquery.validate.min.js")?>"></script>
	<script src="<?php echo js_url("plugins/sweetalert/sweetalert.min.js")?>"></script>
	<script src="<?php echo js_url("jquery-latest.min.js")?>"></script>
	<script src="<?php echo js_url("custom.js")?>"></script>
</body>

</html>
