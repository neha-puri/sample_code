<body class="gray-bg">

    <div class="middle-box text-center loginscreen   animated fadeInDown">
        <div>
            <div>
                <h1 class="logo-name">IN+</h1>
            </div>
            <h3>Register to </h3>
            <p>Create account to see it in action.</p>
			<div class="showtext"></div>
			<div class="alert alert-success" style="display:none;">
                                How quickly daft jumping zebras vex. <a class="alert-link" href="#">Alert Link</a>.
                            </div>
            <form class="m-t" role="form" id="register" method="post" action="/register">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="User Name" required="" name="username" id="username">
                </div>
                <div class="form-group">
                    <input type="email" name="email" id="email" class="form-control" placeholder="Email" required="">
                </div>
               <div class="form-group">
                  <span class="accept-terms" data-toggle="modal" data-target="#termsnconditions"><a href="#" data-toggle="tooltip" data-placement="right" style="color:#676a6c;" title="Click here to accept Terms and Conditions">Agree the terms and policy</a></span> 
				  <label id="terms-error" class="error" for="terms" style="display:none;">Please accept terms and conditions.</label>
				  </div>
				<input class="btn btn-primary block full-width m-b" type="submit" value="Submit" name="submit">
                <p class="text-muted text-center"><small>Already have an account?</small></p>
                <a class="btn btn-sm btn-white btn-block" href="/login">Login</a>
            </form>
        </div>
    </div>
	<!--terms and condition popup-->
	<div class="modal inmodal fade in" id="termsnconditions" tabindex="-1" role="dialog" aria-hidden="true" style="display: none; padding-right: 17px;">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                                            <h4 class="modal-title">Terms and Conditions</h4>
                                        </div>
                                        <div class="modal-body">
                                           <?php echo $description;?>
										  <div class="form-group">
												<div class="checkbox i-checks"><label> <input type="checkbox" name="terms" id="terms"><i></i>  </label><span class="accept-terms"> Agree the terms and policy </span> </div>
										  </div>
										  <input style="float:left; margin-right:10px;" class="btn btn-primary block m-b" data-dismiss="modal" type="submit" value="Submit" name="submit">
								        </div>
								 </div>
                                </div>
	</div>