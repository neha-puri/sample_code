<body class="gray-bg">
    <div class="middle-box text-center loginscreen animated fadeInDown">
        <div>
            <div>
                <h1 class="logo-name">IN+</h1>
            </div>
            <h3>Welcome to Global Asset Care</h3>
            
		   <?php if(isset($_SESSION['logged_in']['link_expired'])) { ?> 
		   <div class="alert alert-danger" style="display:none;">
		   
		   </div>
		   <?php } ?>
		   
		   <form class="m-t" role="form" action="index.html" id="form" method="POST">
                <div class="form-group">
                   	<input id="uname" placeholder="User Name" type="text" value="<?php if(isset($_COOKIE['username'])){echo $_COOKIE['username'];}?>" class="form-control" name="uname" title="Please Enter Username"/>
                </div>
				<div class="form-group">
					<div class="input-group" id="show_hide_password">
				     <input name="password" id="password" placeholder="Password" type="password" class="form-control" value="<?php if(isset($_COOKIE['password'])){echo $_COOKIE['password'];}?>" />
					 <label id="password-error" class="error" for="password" style="display:none"></label>
				    <div class="input-group-addon">
					<a href=""><i class="fa fa-eye-slash" aria-hidden="true"></i></a>
				    </div>
				    </div>
                </div>
				 <div class="form-group">
				<label for="math5" class="captcha">7 + 4 =</label>
				<input type="hidden" name="mathresult" id="mathresult" value=""/>
                <input id="math5" name="math5" class="form-control" placeholder="Captcha" title="Please enter the correct result!" type="text"/>
                </div>
				<div class="form-group">
				<div class="checkbox i-checks"><label style="padding-left:0px;"> <input type="checkbox" name="remember_me" id="remember_me" "<?php if(isset($_COOKIE['username'])){ ?>  checked='checked' <?php } ?>><i></i>  </label><label style="padding-left:9px;" >Remember Me</label></div>
                </div>
				<input class="btn btn-primary block full-width m-b" type="submit" value="Log in">

                <a href="<?php echo base_url("/forgot_password");?>"><small>Forgot password?</small></a>
                <p class="text-muted text-center"><small>Do not have an account?</small></p>
                <a class="btn btn-sm btn-white btn-block" href="register">Create an account</a>
            </form>
        </div>
    </div>