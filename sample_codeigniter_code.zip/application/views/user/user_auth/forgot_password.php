<body class="gray-bg">
    <div class="middle-box text-center loginscreen   animated fadeInDown">
        <div>
            <div>
                <h1 class="logo-name">IN+</h1>
            </div>
            <h3>Forgot password</h3>
			<p>Enter email id. To change the password.</p>
            <div class="showtext"></div>
			<div class="alert alert-success" style="display:none;">
                                How quickly daft jumping zebras vex. <a class="alert-link" href="#">Alert Link</a>.
                            </div>
            <form class="m-t" role="form" id="forgot_password" method="post" action="">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Email" required="" name="email" id="email">
                </div>
            	<input class="btn btn-primary block full-width m-b" type="submit" value="Submit" name="submit">
				
                <p class="text-muted text-center"><small>Do not have an account?</small></p>
                <a class="btn btn-sm btn-white btn-block" href="register">Create an account</a>
            </form>
        </div>
    </div>
   
