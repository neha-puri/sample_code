    <!-- Mainly scripts -->
	<script src="<?php echo js_url("jquery-3.1.1.min.js")?>"></script>
    <script src="<?php echo js_url("bootstrap.min.js")?>"></script>
	<!-- Mainly scripts -->
    <script src="<?php echo js_url("plugins/metisMenu/jquery.metisMenu.js")?>"></script>
    <script src="<?php echo js_url("plugins/slimscroll/jquery.slimscroll.min.js")?>"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo js_url("inspinia.js")?>"></script>
    <script src="<?php echo js_url("plugins/pace/pace.min.js")?>"></script>
	
	<!-- Password meter -->
     <script src="<?php echo js_url("plugins/pwstrength/pwstrength-bootstrap.min.js")?>"></script>
     <script src="<?php echo js_url("plugins/pwstrength/zxcvbn.js")?>"></script>

    <!-- Jquery Validate -->
    <script src="<?php echo js_url("plugins/validate/jquery.validate.min.js")?>"></script>
    <!-- iCheck -->
    <script src="<?php echo js_url("plugins/iCheck/icheck.min.js")?>"></script>
	
    <script src="<?php echo js_url("plugins/jquery-ui/jquery-ui.min.js")?>"></script>

    <script src="<?php echo js_url("custom.js")?>"></script>
    <!-- Chosen -->
    <script src="<?php echo js_url("plugins/chosen/chosen.jquery.js")?>"></script>
	<script src="<?php echo js_url("plugins/datapicker/bootstrap-datepicker.js")?>"></script>

    <!-- Input Mask-->
    <script src="<?php echo js_url("plugins/jasny/jasny-bootstrap.min.js")?>"></script>
	
    <script src="<?php echo js_url("plugins/steps/jquery.steps.min.js")?>"></script>
	<script src="<?php echo js_url("plugins/sweetalert/sweetalert.min.js")?>"></script>
	<script src="<?php echo js_url("jquery-latest.min.js")?>"></script>
	

    <script>
        $(document).ready(function(){
			
			$('[data-toggle="tooltip"]').tooltip({'placement': 'top'});
			
            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green',
                radioClass: 'iradio_square-green',
            });
			
			$("input[type='checkbox']").on('ifChanged', function (e) {
				$(this).val(e.target.checked == true);
			});
			
			$("#register").validate({
				rules: {
				username: {
					required: true,
                    minlength: 3,
					remote: function() {
					return {
                    url: '/user/user_auth/login/validate_uname/' + $('#username').val(),
                    data: '',
					type: "post",
					dataFilter: function (data) {
						if(data!=""){
						return 'false';// If email not exist	
						}else{
						return 'true';// If email exist ( Display message on return true )	
							}
						}
					}
				}
				},
				email:
                {
                    required: true,
                    email: true,
					remote: function() {
                return {
                    url: '/user/user_auth/login/ValidateEmail/' + $('#email').val(),
                    data: '',
					type: "post",
					dataFilter: function (data) {
						if(data!=""){
						return 'false';// If email not exist	
						}else{
						return 'true';// If email exist ( Display message on return true )	
						}
                    }
                }
            }
				}
				
			},
			messages:
             {
                 username:
                 {
                    required: "Please enter your username.",
					minlength: "Please enter atleast 3 characters."	,
					remote: jQuery.validator.format("{0} not available try another.")
                 },
				 email: {
                    required: "Please enter your email.",
					email: "Please enter valid email.",	
					remote: jQuery.validator.format("{0} not available try another.")
                 }
             },
			  submitHandler: function(form) {
					if($("#terms").is(':checked'))
					{
					$("#terms-error").hide();
					$(".icheckbox_square-green").removeClass("checked");
					
					$.ajax({
						url: '/user/user_auth/register/register',
						type: "post",
						data: $(form).serialize(),
						success: function(response) {
							$("#register")[0].reset();
							$(".alert-success").show();
						  $(".alert-success").text("Your account has been created successfully. Please check your email").fadeIn("slow");
						}            
						});
					}
					else{
					$("#terms-error").text("Please accept terms and conditions");
					$("#terms-error").show();
					return false;
					}
				// do some stuff here
			  }
		});
		
        });
		 $().ready(function() {
		
	$("#show_hide_password a").on('click', function(event) {
        event.preventDefault();
        if($('#show_hide_password input').attr("type") == "text"){
            $('#show_hide_password input').attr('type', 'password');
            $('#show_hide_password i').addClass( "fa-eye-slash" );
            $('#show_hide_password i').removeClass( "fa-eye" );
        }else if($('#show_hide_password input').attr("type") == "password"){
            $('#show_hide_password input').attr('type', 'text');
            $('#show_hide_password i').removeClass( "fa-eye-slash" );
            $('#show_hide_password i').addClass( "fa-eye" );
        }
    });
	var a = Math.ceil(Math.random() * 10);
    var b = Math.ceil(Math.random() * 10);
	$(".captcha").html(a+ "+"+ b + " =");
	$("#mathresult").val(a+b);
		$("#form").validate({
		rules: {
				uname: {
					required: true,
                    minlength: 3,
					remote: function() {
							return {
								url: '/user/user_auth/login/validate_uname/' + $('#uname').val(),
								data: '',
								type: "post",
								dataFilter: function (data) {
									if(data!=""){
									return 'true';// If email not exist	
									}else{
									return 'false';// If email exist ( Display message on return true )	
									}
								}
							}
						}					
				},
				password:
                {
                    required: true,
                    minlength: 8
                },
				math5: {
							required: true,
							number: true,
							minlength: 1,
							equalTo: "#mathresult"
				}
			},
			messages:
             {
                 uname:
                 {
                    required: "Please enter your username.",
					minlength: "Please enter your username.",
					remote: jQuery.validator.format("{0} is not exists in our database.")
                 },
				 password: "Please enter a password.",
                 math5: {
					 required: "Please enter the correct result.",
					 number: "Please enter the numbers only.",
					 minlength: "Min length",
					 equalTo: "Please enter the correct result."
				 } 
             },
			  submitHandler: function(form) {
				  
				  var pass= $('#password').val();
				// do some stuff here
				var uname=$('#uname').val();
				var password=$('#password').val();
				var remember_me=$('#remember_me').val();
				
					$.post( "/user/user_auth/login/checklogin/", { uname: uname, password: password, remember_me: remember_me })
					.done(function( data ) {
					 console.log(data);
					 if(data=="loginsuccess"){
					 $.ajax({
							type: "POST",
							url: "/user/user_auth/login/user_login_process/",
							data: $(form).serialize()
						})
						 .done(function (response) {
							 console.log(response);
							if (response == 'success') {               
								document.location="/user/user_auth/login/dashboard"; 							
							} else {
								alert('fail');
							} 
						} );
						return false; // required to block normal submit since you used ajax
					}
						else if(data=="accountblock"){
							$("#password-error").show();
							$("#password-error").text("Your account is blocked");
							return false;
						}
						else if(data=="wrongpassword"){
							$("#password-error").show();
							$("#password-error").text("Your password is wrong");
							return false;
						}
					});
				return false;
			  }
		});
		$(".alert-danger").show();
		$(".alert-danger").text("Your verification link has been expired").fadeIn("slow").delay(5000).fadeOut("slow");
	});
    </script>
	</body>
	</html>