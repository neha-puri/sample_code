<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo css_url("plugins/iCheck/custom.css");?>" rel="stylesheet">
   	<link href="<?php echo css_url("bootstrap.min.css");?>" rel="stylesheet">
    <link href="<?php echo font_awesome("css/font-awesome.css")?>" rel="stylesheet">
    <link href="<?php echo css_url("animate.css");?>" rel="stylesheet">
    <link href="<?php echo css_url("style.css");?>" rel="stylesheet">
	<link href="<?php echo css_url("plugins/sweetalert/sweetalert.css");?>" rel="stylesheet">
	<link href="<?php echo css_url("plugins/chosen/bootstrap-chosen.css");?>" rel="stylesheet">
   	<link href="<?php echo css_url("plugins/jasny/jasny-bootstrap.min.css");?>" rel="stylesheet">
   	<link href="<?php echo css_url("plugins/steps/jquery.steps.css");?>" rel="stylesheet">
    <link href="<?php echo css_url("plugins/dropzone/basic.css");?>" rel="stylesheet">
    <link href="<?php echo css_url("plugins/dropzone/dropzone.css");?>" rel="stylesheet">
	<link href="<?php echo css_url("dataTables.bootstrap4.min.css");?>" rel="stylesheet">
	<link href="<?php echo css_url("buttons.bootstrap4.min.css");?>" rel="stylesheet">
	<link href="<?php echo css_url("select.bootstrap4.min.css");?>" rel="stylesheet">
	
	<style>
	.accept-terms{cursor:pointer;font-weight:700;margin-left:10px;}
	.i-checks label{padding-left :0px}
	#password-error{
	position: absolute;
	top: 33px;
	left: 54px;
	z-index: 111;
	bottom: 10px;}
	
	#password1-error{
	position: absolute;
	top: 33px;
	left: 0px;
	z-index: 111;
	bottom: 10px;
	padding-bottom:10px;
	}
	.model-body{
		padding:19px 28px 47px 30px;
	}
	</style>
</head>