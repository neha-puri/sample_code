<?php 
/**
* Helper css_url()
*
* Usage:
*
* @access public
* @param string
* @return string
*/
if ( ! function_exists('css_url'))
{
function css_url($uri)
{
  $CI =& get_instance();
  return $CI->config->base_url('assets/css/' . $uri);
}
}

/**
* Helper js_url()
*
* Usage:
*
* @access public
* @param string
* @return string
*/
if ( ! function_exists('js_url'))
{
function js_url($uri)
{
  $CI =& get_instance();
  return $CI->config->base_url('assets/js/' . $uri);
}
}
/**
* Helper images_url()
*
* Usage:
*
* @access public
* @param string
* @return string
*/
if ( ! function_exists('images_url'))
{
function images_url($uri)
{
  $CI =& get_instance();
  return $CI->config->base_url('assets/img/' . $uri);
}
}
/**
* Helper font_awesome()
*
* Usage:
*
* @access public
* @param string
* @return string
*/
if ( ! function_exists('font_awesome'))
{
function font_awesome($uri)
{
  $CI =& get_instance();
  return $CI->config->base_url('assets/font-awesome/' . $uri);
}
}
?>