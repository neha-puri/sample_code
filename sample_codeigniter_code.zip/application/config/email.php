<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['protocol'] = "smtp";
$config['smtp_host'] = "ssl://mail.globalassetcare.com";
$config['smtp_port'] = "465";
$config['smtp_user'] = "support@globalassetcare.com";
$config['smtp_pass'] = "P@ssw0rd123";
$config['charset'] = "utf-8";
$config['mailtype'] = "html";
$config['newline'] = "\r\n"; 