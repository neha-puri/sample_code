<?php
class Profile_Model extends CI_model{

public function get_user_list(){
$query = $this->db->query("select `user_id`,`account_status`,`firstname`,`lastname`,`email` ,`account_creation_date` from user");

$result= $query->result();
return $result;
}

public function save_user()
    {
       $postData = $this->input->post();
	   
	   echo "<pre>";
	   print_r($postData);
	   echo "</pre>";
	   
	    $user_id=$postData['user_id'];
		$collection=array();
		 
		 $collection=array(
		'lastname'=>$postData['last_name'],
		'firstname'=>$postData['first_name'],
		'DOB'=> strtotime($postData['dob']),
		'm_a_street_number'=>$postData['m_a_street_number'],
		'm_a_street_address'=>$postData['m_a_street_address'],
		'm_a_country'=>$postData['m_a_country'],
		'm_a_province'=>$postData['m_a_state'],
		'm_a_city'=>$postData['m_a_city'],
		'm_a_postal_code'=>$postData['m_a_postal_code'],
		'm_a_postal_code'=>$postData['m_a_postal_code'],
		'home_phn'=>$postData['h_phn'],
		'cell_phn'=>$postData['c_phn'],
		'b_a_street_number'=>$postData['b_a_street_number'],
		'b_a_street_address'=>$postData['b_a_street_address'],
		'b_a_postal_code'=>$postData['b_a_postal_code'],
		'b_a_country'=>$postData['b_a_country'],
		'b_a_province'=>$postData['b_a_state'],
		'b_a_city'=>$postData['b_a_city'],
		'note'=>$postData['note'],
		'h_c_code'=>$postData['h_c_code'],
		'cl_c_code'=>$postData['cl_c_code'],
		'account_creation_date'=> date('Y-m-d H:i:s')
     	);
		
		if(isset($postData['username'])&& ($postData['username']!="")){
		$collection['username']= $postData['username'];
		}
		
		if(isset($postData['email'])&& ($postData['email']!="")){
			$collection['email']= $postData['email'];
		}
		
		if(isset($postData['password'])&& ($postData['password']!="")){
			$collection['password']= $postData['password'];
		}
		if(isset($postData['password'])&& ($postData['password']!="")){
			$collection['hash']= md5($postData['password']);
		}
            $this->db->where('user_id', $user_id);
            $this->db->update('user', $collection);
			echo "editsuccess";
    }

public function get_user_detail($id){
$query = $this->db->query("select * from user where user_id='".$id."'");

$result= $query->row();
return $result;
}

public function get_cities_list($id){
$id= urldecode($id);
$query = $this->db->query("select city from location where state='".$id."'");

$result= $query->result();
return $result;
}

public function get_province_list($id){
$id= urldecode($id);
$query = $this->db->query("select DISTINCT state from location where country_code='".$id."'");

$result= $query->result();
return $result;
}

public function get_country_list(){
$query = $this->db->query("select DISTINCT country,country_code from location ");

$result= $query->result();
return $result;
}

}