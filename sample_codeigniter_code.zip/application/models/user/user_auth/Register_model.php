<?php
class Register_model extends CI_model{

public function adduser($user){
	$usernameExists = $this->db->query("select username from user where username='".$user['username']."'");
	$username = $usernameExists->row();
	$emailExists = $this->db->query("select email from user where email='".$user['email']."'");
	$email = $emailExists->row();
	
	if((isset($username->username)&& $username->username !="") && (isset($email->email)&& $email->email !="")){
		echo "Already Exists";
	}else{
	$hash = md5( rand(0,1000) );
	
	$account_no = $this->db->query("SELECT FLOOR(RAND() * 9999999999) AS random_num FROM user WHERE 'random_num' NOT IN (SELECT account_number FROM user) LIMIT 1 ");
	$account_no = $account_no->row();
	$account_no=$account_no->random_num;
	
	$password = $this->db->query("SELECT FLOOR(RAND() * 999999) AS random_num FROM user WHERE 'random_num' NOT IN (SELECT password FROM user) LIMIT 1 ");
	$password = $password->row();
	$password=$password->random_num;
	
	$this->db->set('username', $user['username']);
	$this->db->set('email', $user['email']);
	$this->db->set('usertype', 3);
	$this->db->set('hash', $hash);
	$this->db->set('account_number', $account_no);
	$this->db->set('password', $password);
	$this->db->set('account_creation_date', date('Y-m-d H:i:s'));
	$this->db->insert('user'); 
	}
	return $hash.",".$user['email'].",".$password.",".$user['username'];
	/*$this->db->insert('user', $user),; */
}

function user_verified($user_id,$hash){
$data=array('email_verify'=>'1');
$this->db->where("(user_id='".$user_id."' AND hash='".$hash."')", NULL, FALSE);
$this->db->update('user',$data);
$result= $this->db->affected_rows();
if($result){
	return $result;
}else{
	return '0';
}
//echo $this->db->last_query(); 
}

function change_password($pwd,$oldpassword){
$createdby  =   $this->session->userdata();
$userid=$createdby['logged_in']['user_id'] ;

$data=array('password'=>$pwd);
$this->db->where("(user_id='".$userid."' and password='".$oldpassword."')", NULL, FALSE);
$this->db->update('user',$data);

//echo $this->db->last_query();  
$result1= $this->db->affected_rows();

if($result1==1){

$last_password = $this->db->query("select password,user_id from user where user_id='".$userid."'");
$last_password = $last_password->row();

/*check password history for particular user*/
$query = $this->db->query("select count(*) as pwd_history from password_history where user_id='".$last_password->user_id."'");
$result=$query->result();
/*check password history for particular user*/
if($result[0]->pwd_history<6)
{
$date = date('Y-m-d H:i:s');
$post_data=array('user_id'=>$last_password->user_id,'password'=>$last_password->password,'created_date'=>$date);
$this->db->insert('password_history', $post_data);
}elseif($result[0]->pwd_history >=6){
	$this->db->delete('password_history', array('user_id' => $last_password->user_id));
	$date = date('Y-m-d H:i:s');
	$post_data=array('user_id'=>$last_password->user_id,'password'=>$last_password->password,'created_date'=>$date);
	$this->db->insert('password_history', $post_data);
}

//echo $this->db->last_query(); 
$result= $this->db->affected_rows();
if($result){
	echo $result;
}
}
if($result1==0){
	echo "wrong oldpassword";
}
//echo $this->db->last_query(); 
}

function get_user_detail($email){

$query = $this->db->query("select hash,email,user_id from user where email='".$email."'");
$result=$query->result();
return $result;

//echo $this->db->last_query(); 
}
function get_terms_conditions(){
 $query = $this->db->query("select `description` from terms_conditions");
 $result= $query->result();
 return $result;
}

function update_user_pwd($tmp_pwd,$email){
	
$data=array('password'=>$tmp_pwd);
$this->db->where("(email='".$email."')", NULL, FALSE);
$this->db->update('user',$data);

//echo $this->db->last_query();  
$result1= $this->db->affected_rows();
}

}