<?php
class Login_Model extends CI_model{
public function validate_username($username){
$query = $this->db->query("select 1 
from (
    select username as username from user
    union all
    select username from admins
    union all
    select username from support
) a
where username = '".$username."' ");

$row = $query->row();

if (isset($row))
{
        echo $username; 
}
}

public function validate_email($email){
$query = $this->db->query("select 1 
from (
    select email as email from user
    union all
    select email from admins
    union all
    select email from support
) a
where email = '".$email."'");

$row = $query->row();

if (isset($row))
{
        echo $row->email;
}
}

public function validate_password($pwd,$userid){
//$query = $this->db->query("select user_id from user where hash='".$hashid."'");
$query = $this->db->query("select user_id from user where user_id='".$userid."'");

$row = $query->row();

if (isset($row))
{
		$query = $this->db->query("select count(password) as pwdcount from password_history where user_id='".$row->user_id."' and password='".$pwd."'" );

		$row = $query->result();
		echo $row[0]->pwdcount;
}
}

public function checklogin($username,$pwd){
$activeuser = $this->db->query("select * from user where username='".$username."' and password='".$pwd."' and account_status!='1'");
$activeuser = $activeuser->row();
$blockeduser_after_24hours = $this->db->query("select * from user where username='".$username."' and password='".$pwd."' and account_status ='1'");
$blockeduser = $blockeduser_after_24hours->row();
if(isset($blockeduser)){
$date1=$blockeduser->last_attempt_date;

$datetime1 = new DateTime();
$datetime2 = new DateTime($date1);
$interval = $datetime1->diff($datetime2);
$elapsed = $interval->format('%a');
}

if (isset($activeuser) || isset($blockeduser)&& $elapsed >=1)
{
			$currentdate = date('Y-m-d H:i:s');
			 $data = array(
			'account_status' => '0',
			'attempt_count' => '0',
			'last_attempt_date' => $currentdate
			);
			$this->db->where('username', $username);
			$this->db->update('user', $data); 
        echo "loginsuccess";
}
else{		
	$query = $this->db->query("select attempt_count,account_status from user where username='".$username."' and password='".$pwd."'");    
	$row = $query->row();
	$query1 = $this->db->query("select attempt_count,account_status from user where username='".$username."'");    
	$row1= $query1->row(); 
	if(isset($row->attempt_count)&& $row->attempt_count== 5 || isset($row1->attempt_count)&& $row1->attempt_count== 5 || isset($row1->account_status) && $row1->account_status ==1){			
	$data = array('account_status' => '1');
	$this->db->where('username', $username);	
	$this->db->update('user', $data); 		
	echo "accountblock"; die();
	}	
	else{
		if(isset($row->attempt_count) && $row->attempt_count!=""){
		$updated_count= $row->attempt_count+1;	
		}
		if(isset($row1->attempt_count) && $row1->attempt_count!=""){
		$updated_count1= $row1->attempt_count+1;
		}
		if(isset($updated_count)){
		if($updated_count<=5){
			 $currentdate = date('Y-m-d H:i:s');
			 $data = array(
			'attempt_count' => $updated_count,
			'last_attempt_date' => $currentdate
			);
			$this->db->where('username', $username);
			$this->db->update('user', $data); 		
			$result= $this->db->affected_rows();	
			if($result>0){			
			echo 'wrongpassword';			
			}
		}	}
		if(isset($updated_count1)){
			if($updated_count1<=5){
			 $currentdate = date('Y-m-d H:i:s');
			 $data = array(
			'attempt_count' => $updated_count1,
			'last_attempt_date' => $currentdate
			);
			$this->db->where('username', $username);
			$this->db->update('user', $data); 		
			$result= $this->db->affected_rows();	
			if($result>0){			
			echo 'wrongpassword';			
			}
		}}
		}}}
public function adduser($user){
	$usernameExists = $this->db->query("select username from user where username='".$user['username']."'");
	$username = $usernameExists->row();
	$emailExists = $this->db->query("select email from user where email='".$user['email']."'");
	$email = $emailExists->row();
	
	if((isset($username->username)&& $username->username !="") && (isset($email->email)&& $email->email !="")){
		echo "Already Exists";
	}else{
	$this->db->set('username', $user['username']);
	$this->db->set('email', $user['email']);
	$this->db->set('usertype', 3);
	$this->db->insert('user'); 
	}
	/*$this->db->insert('user', $user); */
}
public function get_login_user_id($uname,$password)
{
	$user_id = $this->db->query("select user_id ,firstname ,account_number,lastname from user where username='".$uname."' and password='".$password."'");
	$user_id = $user_id->row();
	return $user_id;
}
}